import { useState, useEffect } from 'react';

function App() {
  const [status, setStatus] = useState('Checking...');

  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => setStatus('API Connected: ' + data.status))
      .catch(() => setStatus('API Offline'));
  }, []);

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-12 text-center">
          <h1>AssetFlow v1.0</h1>
          <p className="lead">Asset Management System</p>
          <div className="alert alert-info mt-4">
            <h4>Deployment Status</h4>
            <p><strong>Backend API:</strong> {status}</p>
            <p><strong>Frontend:</strong> Running</p>
          </div>
          <div className="mt-4">
            <p>The application is successfully deployed!</p>
            <small className="text-muted">Full UI pages will be added in the next deployment</small>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
