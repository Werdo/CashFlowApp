import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AssetDashboard from './pages/AssetDashboard';
import AssetList from './pages/Assets/AssetList';
import DepositDashboard from './pages/Deposit/DepositDashboard';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AssetDashboard />} />
        <Route path="/assets" element={<AssetList />} />
        <Route path="/deposit" element={<DepositDashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
