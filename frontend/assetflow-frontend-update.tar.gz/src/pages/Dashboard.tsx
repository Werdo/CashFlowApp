import { useState } from 'react';

interface DashboardProps {
  user: any;
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeMenu, setActiveMenu] = useState('dashboard');

  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊' },
    { id: 'assets', name: 'Activos', icon: '📦' },
    { id: 'maintenance', name: 'Mantenimiento', icon: '🔧' },
    { id: 'movements', name: 'Movimientos', icon: '🔄' },
    { id: 'deposit', name: 'Depósito', icon: '🏢' },
    { id: 'reports', name: 'Reportes', icon: '📈' },
  ];

  const stats = [
    { title: 'Total Activos', value: '1,234', change: '+12%', color: 'primary' },
    { title: 'Valor Total', value: '$2.5M', change: '+8%', color: 'success' },
    { title: 'Mantenimientos', value: '45', change: '-3%', color: 'warning' },
    { title: 'En Depósito', value: '89', change: '+5%', color: 'info' },
  ];

  return (
    <div className="d-flex" style={{ height: '100vh' }}>
      {/* Sidebar */}
      <div className="bg-dark text-white" style={{ width: '250px', overflowY: 'auto' }}>
        <div className="p-4">
          <h4 className="fw-bold mb-0">AssetFlow</h4>
          <small className="text-muted">v1.0.0</small>
        </div>

        <div className="px-3">
          <div className="mb-3">
            <div className="d-flex align-items-center p-2 bg-secondary bg-opacity-25 rounded">
              <div className="me-2">
                <div className="rounded-circle bg-primary d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px' }}>
                  <span className="fw-bold">{user?.name?.charAt(0) || 'U'}</span>
                </div>
              </div>
              <div className="flex-grow-1">
                <div className="fw-bold small">{user?.name || 'Usuario'}</div>
                <div className="text-muted" style={{ fontSize: '0.75rem' }}>{user?.role || 'Usuario'}</div>
              </div>
            </div>
          </div>

          <nav className="nav flex-column">
            {menuItems.map((item) => (
              <a
                key={item.id}
                href="#"
                className={`nav-link text-white ${activeMenu === item.id ? 'bg-primary rounded' : ''}`}
                onClick={(e) => {
                  e.preventDefault();
                  setActiveMenu(item.id);
                }}
              >
                <span className="me-2">{item.icon}</span>
                {item.name}
              </a>
            ))}

            <hr className="bg-secondary" />

            <a href="#" className="nav-link text-white" onClick={(e) => { e.preventDefault(); onLogout(); }}>
              <span className="me-2">🚪</span>
              Cerrar Sesión
            </a>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 bg-light" style={{ overflowY: 'auto' }}>
        {/* Header */}
        <div className="bg-white border-bottom p-3">
          <div className="container-fluid">
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <h5 className="mb-0">
                  {menuItems.find(item => item.id === activeMenu)?.icon}{' '}
                  {menuItems.find(item => item.id === activeMenu)?.name || 'Dashboard'}
                </h5>
                <small className="text-muted">Bienvenido, {user?.name}</small>
              </div>
              <div>
                <span className="badge bg-success me-2">API: Activo</span>
                <span className="badge bg-success">DB: Conectada</span>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container-fluid p-4">
          {activeMenu === 'dashboard' && (
            <>
              {/* Stats Cards */}
              <div className="row g-3 mb-4">
                {stats.map((stat, index) => (
                  <div key={index} className="col-md-6 col-lg-3">
                    <div className="card border-0 shadow-sm">
                      <div className="card-body">
                        <div className="d-flex justify-content-between align-items-start">
                          <div>
                            <p className="text-muted mb-1 small">{stat.title}</p>
                            <h3 className="mb-0 fw-bold">{stat.value}</h3>
                            <small className={`text-${stat.color}`}>
                              {stat.change} vs mes anterior
                            </small>
                          </div>
                          <div className={`p-2 bg-${stat.color} bg-opacity-10 rounded`}>
                            <span className={`text-${stat.color}`} style={{ fontSize: '1.5rem' }}>
                              {menuItems.find(item => item.id === stat.title.toLowerCase().split(' ')[0])?.icon || '📊'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Charts Row */}
              <div className="row g-3 mb-4">
                <div className="col-lg-8">
                  <div className="card border-0 shadow-sm">
                    <div className="card-header bg-white">
                      <h6 className="mb-0">Activos por Categoría</h6>
                    </div>
                    <div className="card-body">
                      <div className="d-flex justify-content-around align-items-end" style={{ height: '200px' }}>
                        <div className="text-center">
                          <div className="bg-primary mb-2" style={{ width: '60px', height: '120px' }}></div>
                          <small>Equipos</small>
                        </div>
                        <div className="text-center">
                          <div className="bg-success mb-2" style={{ width: '60px', height: '90px' }}></div>
                          <small>Mobiliario</small>
                        </div>
                        <div className="text-center">
                          <div className="bg-warning mb-2" style={{ width: '60px', height: '150px' }}></div>
                          <small>Vehículos</small>
                        </div>
                        <div className="text-center">
                          <div className="bg-info mb-2" style={{ width: '60px', height: '70px' }}></div>
                          <small>Otros</small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-lg-4">
                  <div className="card border-0 shadow-sm">
                    <div className="card-header bg-white">
                      <h6 className="mb-0">Actividad Reciente</h6>
                    </div>
                    <div className="card-body">
                      <div className="list-group list-group-flush">
                        <div className="list-group-item px-0 border-0">
                          <small className="text-muted">Hace 5 min</small>
                          <p className="mb-0 small">Nuevo activo registrado: Laptop Dell</p>
                        </div>
                        <div className="list-group-item px-0 border-0">
                          <small className="text-muted">Hace 1 hora</small>
                          <p className="mb-0 small">Mantenimiento completado: Vehículo #123</p>
                        </div>
                        <div className="list-group-item px-0 border-0">
                          <small className="text-muted">Hace 2 horas</small>
                          <p className="mb-0 small">Transferencia a Depósito: 5 items</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Assets Table */}
              <div className="card border-0 shadow-sm">
                <div className="card-header bg-white d-flex justify-content-between align-items-center">
                  <h6 className="mb-0">Activos Recientes</h6>
                  <button className="btn btn-sm btn-primary">Ver Todos</button>
                </div>
                <div className="card-body p-0">
                  <div className="table-responsive">
                    <table className="table table-hover mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>ID</th>
                          <th>Nombre</th>
                          <th>Categoría</th>
                          <th>Estado</th>
                          <th>Ubicación</th>
                          <th>Valor</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#A-001</td>
                          <td>Laptop Dell XPS 15</td>
                          <td><span className="badge bg-primary">Equipos</span></td>
                          <td><span className="badge bg-success">Activo</span></td>
                          <td>Oficina Central</td>
                          <td>$1,500</td>
                        </tr>
                        <tr>
                          <td>#A-002</td>
                          <td>Escritorio Ejecutivo</td>
                          <td><span className="badge bg-success">Mobiliario</span></td>
                          <td><span className="badge bg-success">Activo</span></td>
                          <td>Piso 3 - Oficina 301</td>
                          <td>$800</td>
                        </tr>
                        <tr>
                          <td>#A-003</td>
                          <td>Vehículo Toyota Corolla</td>
                          <td><span className="badge bg-warning">Vehículos</span></td>
                          <td><span className="badge bg-warning">Mantenimiento</span></td>
                          <td>Taller</td>
                          <td>$18,000</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeMenu !== 'dashboard' && (
            <div className="card border-0 shadow-sm">
              <div className="card-body text-center py-5">
                <div style={{ fontSize: '4rem' }}>
                  {menuItems.find(item => item.id === activeMenu)?.icon}
                </div>
                <h4 className="mt-3">Módulo {menuItems.find(item => item.id === activeMenu)?.name}</h4>
                <p className="text-muted">
                  Esta sección está en desarrollo. Conecta con el backend en /api/{activeMenu}
                </p>
                <button className="btn btn-primary mt-3">
                  Próximamente
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
