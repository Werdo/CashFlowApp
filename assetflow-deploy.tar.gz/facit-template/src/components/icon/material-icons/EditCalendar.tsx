import React, { SVGProps } from 'react';

const SvgEditCalendar = (props: SVGProps<SVGSVGElement>) => {
	return (
		<svg viewBox='0 0 24 24' fill='currentColor' className='svg-icon' {...props}>
			<path fill='none' d='M0 0h24v24H0z' />
			<path opacity={0.3} d='M5 6h14v2H5z' />
			<path d='M5 10h14v2h2V6c0-1.1-.9-2-2-2h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20a2 2 0 002 2h7v-2H5V10zm0-4h14v2H5V6zm17.84 10.28l-.71.71-2.12-2.12.71-.71a.996.996 0 011.41 0l.71.71c.39.39.39 1.02 0 1.41zm-3.54-.7l2.12 2.12-5.3 5.3H14v-2.12l5.3-5.3z' />
		</svg>
	);
};

export default SvgEditCalendar;
